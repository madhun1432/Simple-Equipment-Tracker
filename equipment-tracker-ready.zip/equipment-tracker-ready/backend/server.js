
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const { v4: uuid } = require("uuid");

const app = express();
const PORT = 5000;
const DATA_FILE = "./equipment.json";

app.use(cors());
app.use(express.json());

const readData = () => {
  if (!fs.existsSync(DATA_FILE)) return [];
  return JSON.parse(fs.readFileSync(DATA_FILE));
};

const writeData = (data) => {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
};

app.get("/api/equipment", (req, res) => {
  res.json(readData());
});

app.post("/api/equipment", (req, res) => {
  const data = readData();
  const item = { id: uuid(), ...req.body };
  data.push(item);
  writeData(data);
  res.status(201).json(item);
});

app.put("/api/equipment/:id", (req, res) => {
  const data = readData();
  const index = data.findIndex(e => e.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: "Not found" });
  data[index] = { ...data[index], ...req.body };
  writeData(data);
  res.json(data[index]);
});

app.delete("/api/equipment/:id", (req, res) => {
  const data = readData().filter(e => e.id !== req.params.id);
  writeData(data);
  res.json({ message: "Deleted" });
});

app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
