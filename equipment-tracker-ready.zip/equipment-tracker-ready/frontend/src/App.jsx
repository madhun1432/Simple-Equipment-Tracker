import { useState } from "react";

function App() {
  const [equipmentList, setEquipmentList] = useState([]);
  const [name, setName] = useState("");
  const [type, setType] = useState("Mixer");
  const [status, setStatus] = useState("Inactive");
  const [lastCleaned, setLastCleaned] = useState("");
  const [editIndex, setEditIndex] = useState(null);

  // ADD / UPDATE
  const handleSave = () => {
    if (editIndex === null) {
      setEquipmentList([
        ...equipmentList,
        { name, type, status, lastCleaned }
      ]);
    } else {
      const updatedList = [...equipmentList];
      updatedList[editIndex] = { name, type, status, lastCleaned };
      setEquipmentList(updatedList);
      setEditIndex(null);
    }

    setName("");
    setType("Mixer");
    setStatus("Inactive");
    setLastCleaned("");
  };

  // EDIT
  const handleEdit = (index) => {
    const item = equipmentList[index];
    setName(item.name);
    setType(item.type);
    setStatus(item.status);
    setLastCleaned(item.lastCleaned);
    setEditIndex(index);
  };

  // DELETE
  const handleDelete = (index) => {
    setEquipmentList(equipmentList.filter((_, i) => i !== index));
  };

  return (
    <div>
      <h1>Equipment Tracker</h1>

      <input
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <select value={type} onChange={(e) => setType(e.target.value)}>
        <option>Mixer</option>
        <option>Oven</option>
        <option>Grinder</option>
      </select>

      <select value={status} onChange={(e) => setStatus(e.target.value)}>
        <option>Active</option>
        <option>Inactive</option>
      </select>

      <input
        type="date"
        value={lastCleaned}
        onChange={(e) => setLastCleaned(e.target.value)}
      />

      <button onClick={handleSave}>
        {editIndex === null ? "Add" : "Update"}
      </button>

      <table border="1">
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Status</th>
            <th>Last Cleaned</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {equipmentList.map((item, index) => (
            <tr key={index}>
              <td>{item.name}</td>
              <td>{item.type}</td>
              <td>{item.status}</td>
              <td>{item.lastCleaned}</td>
              <td>
                <button onClick={() => handleEdit(index)}>Edit</button>
                <button onClick={() => handleDelete(index)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
